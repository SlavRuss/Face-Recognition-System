import requests
import csv
import os
from PIL import Image
import io
import base64
import psycopg2
import re

API_URL = "https://randomuser.me/api/"
OUTPUT_DIR = "images"
CSV_FILE = "employees.csv"
ALLOWED_FORMATS = {"JPEG", "PNG"}
REG = re.compile(r'^[A-Za-z\s\-]+$')
POSITIONS = [
    "Software Engineer",
    "Manager",
    "HR",
    "Analyst",
    "DevOps Engineer",
    'Designer',
    'Data Engineer',
    '3D Designer',
    'Product Manager'
]
df = []

def get_users(count=50):
    response = requests.get(API_URL, params={"results": count})
    response.raise_for_status()
    return response.json()["results"]


def download_validate(url, filepath):
    response = requests.get(url, timeout=5)
    if response.status_code != 200:
        raise ValueError(f"Не скачалось: {url}")
    content = response.content

    try:
        image = Image.open(io.BytesIO(content))
    except Exception:
        raise ValueError("Не картинка")

    if image.format not in ALLOWED_FORMATS:
        raise ValueError(f"Не тот формат: {image.format}")
    with open(filepath, "wb") as f:
        f.write(content)


def binary_path(filepath):
    with open(filepath, "rb") as f:
        photo_bytes = f.read()
    return base64.b64encode(photo_bytes).decode("utf-8")


def main(d):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    users = get_users(50)
    file_exists = os.path.exists(CSV_FILE)

    with open(CSV_FILE, "a", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)

        if not file_exists:
            writer.writerow(["filename", "employee_id", "full_name", "position"])
        id_emp = len(d) + 1
        for user in users:
            first = user["name"]["first"]
            last = user["name"]["last"]
            full_name = f"{first} {last}"
            if not REG.match(full_name):
                continue

            image_url = user["picture"]["large"]
            filename = f"{first.lower()}_{last.lower()}_{id_emp}.jpg"
            filepath = os.path.join(OUTPUT_DIR, filename)
            download_validate(image_url, filepath)


            position = POSITIONS[id_emp % len(POSITIONS)]
            writer.writerow([filename, id_emp, full_name, position])

            user = {
                'full_name': full_name,
                'position': position,
                'photo': binary_path(filepath)
            }
            d.append(user)
            id_emp += 1
    return d


def db_write(d):
    try:
        conn = psycopg2.connect(
            dbname='*****',
            user='*****',
            password='*****',
            host='*****'
        )
        cur = conn.cursor()
        cur.execute("SET search_path TO face_recognition")

        table_create_query = """
            CREATE TABLE IF NOT EXISTS employees
            (id SERIAL PRIMARY KEY NOT NULL,
            full_name VARCHAR(70) NOT NULL,
            position VARCHAR(50) NOT NULL,
            photo TEXT NOT NULL);
        """
        cur.execute(table_create_query)
        conn.commit()

        if d:
            query = """
                INSERT INTO employees(full_name, position, photo) 
                VALUES (%(full_name)s, %(position)s, %(photo)s) 
            """
            cur.executemany(query, d)
            conn.commit()

    except Exception as e:
        print(f"Database error: {e}")
        conn.rollback()

    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

if __name__ == "__main__":
    for i in range(10):
        main(df)
    db_write(df)